
#include <stdio.h>

int main (void){
    FILE *arquivo;
    int numeros[5];
   
    
    for(int i = 0; i < 5; i++){
        printf("Digite um número: ");
        scanf("%d", &numeros[i]);
    }
    
    arquivo = fopen("numeros.txt", "a");
    
    if (arquivo == NULL) {
    perror("Erro ao abrir arquivo");
    }
    
    fprintf(arquivo, "%d\n", numeros[0]);
    fprintf(arquivo, "%d\n", numeros[1]);
    fprintf(arquivo, "%d\n", numeros[2]);
    fprintf(arquivo, "%d\n", numeros[3]);
    fprintf(arquivo, "%d\n", numeros[4]);
    
    if (fclose(arquivo) != 0) {
    perror("Erro ao salvar os numeros");
    }
     
    else {
    printf("\nNumeros cadastrados com sucesso!\n");
    printf("Numeros salvos em numeros.txt\n");
}
}