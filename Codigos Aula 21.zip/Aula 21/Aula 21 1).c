
#include <stdio.h>

typedef struct{
    char nome[50];
    int matricula;
} Funcionario;

int main (void){
    FILE *arquivo;
    Funcionario f;
    int total;
    int qnt_funcionario;


    printf("Quantidade de pacientes que ira armazenar (1 a 5): ");
	scanf("%d", &qnt_funcionario);
	
	if(qnt_funcionario < 1 || qnt_funcionario > 5){
	    printf("Número inválido!");
	    return 0;
	}

    for(int i = 0; i < qnt_funcionario; i++){
        printf("\n========== FUNCIONÁRIO %d ==========\n", i + 1);
        
        printf("Nome: ");
        scanf("%49s", f.nome);
        
        printf("Matrícula: ");
        scanf("%d", &f.matricula);
    }
    arquivo = fopen("funcionarios.txt", "a");
    
    if (arquivo == NULL) {
    perror("Erro ao abrir arquivo");
    }
    
    fprintf(arquivo, "========================================\n");
     
    fprintf(arquivo, "\nFUNCIONARIO: %s\n", f.nome);
    fprintf(arquivo, "\nMatrícula: %d\n", f.matricula);
    fprintf(arquivo, "\n----------------------------------------\n");
    
    if (fclose(arquivo) != 0) {
    perror("Erro ao salvar os dados");
    }
     
    else {
    printf("\nFuncionario cadastrado com sucesso!\n");
    printf("Dados salvos em funcionarios.txt\n");
}
}