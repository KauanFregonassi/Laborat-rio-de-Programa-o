
#include <stdio.h>
#include <string.h>

typedef struct {
    char nome[50];
    float salario;
    int horasExtras;
} Funcionario;

int main() {

    Funcionario funcionarios[5];
    int quantidade, i;
    FILE *arquivo;

    printf("=== CADASTRO DE FUNCIONARIOS ===\n");

    printf("Quantos funcionarios deseja cadastrar (maximo 5)? ");
    scanf("%d", &quantidade);
    getchar();

    if (quantidade < 1 || quantidade > 5) {
        printf("Quantidade invalida!\n");
        return 1;
    }

    for (i = 0; i < quantidade; i++) {

        printf("\nFuncionario %d\n", i + 1);

        printf("Nome: ");
        fgets(funcionarios[i].nome, 50, stdin);

        funcionarios[i].nome[strcspn(funcionarios[i].nome, "\n")] = '\0';

        printf("Salario: R$ ");
        scanf("%f", &funcionarios[i].salario);

        printf("Horas extras: ");
        scanf("%d", &funcionarios[i].horasExtras);

        getchar();
    }

    arquivo = fopen("funcionarios.txt", "a");

    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }

    for (i = 0; i < quantidade; i++) {

        fprintf(arquivo, "==============================\n");
        fprintf(arquivo, "FUNCIONARIO %d\n", i + 1);
        fprintf(arquivo, "Nome: %s\n", funcionarios[i].nome);
        fprintf(arquivo, "Salario: R$ %.2f\n", funcionarios[i].salario);
        fprintf(arquivo, "Horas extras: %d\n", funcionarios[i].horasExtras);
        fprintf(arquivo, "==============================\n\n");
    }

    fclose(arquivo);

    printf("\nDados gravados com sucesso!\n");

    arquivo = fopen("funcionarios.txt", "r");

    if (arquivo == NULL) {
        printf("Erro ao ler o arquivo!\n");
        return 1;
    }

    printf("\n=== FUNCIONARIOS CADASTRADOS ===\n");

    char linha[100];

    while (fgets(linha, 100, arquivo) != NULL) {
        printf("%s", linha);
    }

    fclose(arquivo);

    return 0;
}
