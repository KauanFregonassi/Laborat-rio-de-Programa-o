
#include <stdio.h>
#include <string.h>

int main(void)
{
    char nome[50];
    char nomeCopia[50];
    char codigo[10];
    char curso[50];
    char mensagem[100] = "Ola, ";

    printf("===== IDENTIFICACAO ACADEMICA =====\n");

    printf("Nome do estudante: ");
    scanf("%49s", nome);

    printf("Codigo do curso (CC ou SI): ");
    scanf("%9s", codigo);

    if (strcmp(codigo, "CC") == 0)
    {
        strcpy(curso, "Ciencia da Computacao");
    }
    else if (strcmp(codigo, "SI") == 0)
    {
        strcpy(curso, "Sistemas de Informacao");
    }

    int quantidade = strlen(nome);

    strcpy(nomeCopia, nome);

    strcat(mensagem, nomeCopia);
    strcat(mensagem, "!");

    printf("\n===== RESULTADO =====\n");
    printf("Estudante: %s\n", nomeCopia);
    printf("Curso: %s\n", curso);
    printf("Caracteres no nome: %d\n", quantidade);
    printf("\n%s\n", mensagem);

    return 0;
}
