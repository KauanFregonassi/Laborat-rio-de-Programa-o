#include <string.h>
#include <stdio.h>

int main()
{
    char produto[50];
    char categoria[20];
    char descricao[100] = "Produto: ";
    char confirmacao[50];
    
    printf(" \n===== CADASTRO DE PRODUTOS =====\n");
    
    printf("Nome do produto: ");
    scanf("%49s", produto);
    
    printf("Qual a categoria do produto(HARDWARE ou PERIFERICO): ");
    scanf("%19s", categoria);
    
    strcpy(confirmacao, produto);
    
    strcat(descricao, produto);
    
    
    printf("\n===== RESUMO =====\n");
    
    printf("Produto: %s\n", produto);
    printf("Caracteres: %zu\n", strlen(confirmacao));
    
    if(strcmp(categoria, "HARDWARE") == 0){
        printf("Categoria: Hardware\n");
    }
    else{
        printf("Categoria: Periferico\n");
    }
    
    printf("Descricao: %s\n", descricao);
    printf("Cadastro concluido!");
    

    return 0;
}