#include <string.h>
#include <stdio.h>

int main()
{
    char nome[50];
    char perfil[20];
    char confirmacao[50];
    char texto[100] = "Bem-Vindo(a), ";
    
    printf("\n===== CADASTROS DE USUÁRIOS =====\n");
    printf("Digite seu nome: ");
    scanf("%49s", nome);
    printf("Digite seu perfil (ADMIN ou COMUM): ");
    scanf("%19s", perfil);
    
    strcpy(confirmacao, nome);
    
    strcat(texto, nome);
    strcat(texto, "!");
    
    
    printf("\n===== DADOS CADASTRADOS =====\n");
    
    printf("Nome: %s\n", nome);
    printf("Quantidade de caracteres: %zu\n", strlen(nome));
    
    if(strcmp(perfil, "ADMIN") == 0){
        printf("Perfil: Administrador\n");
    }
    else{
        printf("Perfil: Comum\n");
    }
    
    printf( "%s\n", texto);
    printf("Cadastro realizado com sucesso.");
    

    return 0;
}