
#include <stdio.h>

void exibirLinha() {
    printf("**********\n");
}

int main(void) {

    exibirLinha();

    printf("RELATORIO DE ESTOQUE\n");

    exibirLinha();

    return 0;
}
