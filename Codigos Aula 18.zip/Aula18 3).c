#include <stdio.h>

int verificarPar(int n){
    if(n%2 == 0){
        return 1;
    }
    else{
        return 0;
    }
}
int main(void){
    int n;
    printf("Digite um numero: ");
    scanf("%d", &n);
    if(verificarPar(n)){
        printf("O numero %d é par", verificarPar(n));
    }
    else{
        printf("O numero %d é impar", verificarPar(n));
    }


    return 0;
}