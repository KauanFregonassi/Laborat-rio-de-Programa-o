
#include <stdio.h>

int dobro(int quantidade) {
    return quantidade * 2;
}

int main(void) {
    int quantidade, quantidadeFinal;

    printf("Digite a quantidade inicial: ");
    scanf("%d", &quantidade);

    quantidadeFinal = dobro(quantidade);

    printf("Quantidade inicial: %d\n", quantidade);
    printf("Quantidade apos duplicacao: %d\n", quantidadeFinal);

    return 0;
}
