
#include <stdio.h>


int somar(int a, int b) {
    return a + b;
}

int subtrair(int a, int b) {
    return a - b;
}

int multiplicar(int a, int b) {
    return a * b;
}

int dividir(int a, int b) {
    return a / b;
}


void exibirMenu() {
    printf("\n===== CALCULADORA =====\n");
    printf("1 - Somar\n");
    printf("2 - Subtrair\n");
    printf("3 - Multiplicar\n");
    printf("4 - Dividir\n");
    printf("5 - Sair\n");
}

int main(void) {
    int opcao, a, b, resultado;

    do {
        exibirMenu();

        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao >= 1 && opcao <= 4) {

            printf("Digite o primeiro numero: ");
            scanf("%d", &a);

            printf("Digite o segundo numero: ");
            scanf("%d", &b);

            switch(opcao) {

                case 1:
                    resultado = somar(a, b);
                    printf("Resultado: %d\n", resultado);
                    break;

                case 2:
                    resultado = subtrair(a, b);
                    printf("Resultado: %d\n", resultado);
                    break;

                case 3:
                    resultado = multiplicar(a, b);
                    printf("Resultado: %d\n", resultado);
                    break;

                case 4:
                    if (b != 0) {
                        resultado = dividir(a, b);
                        printf("Resultado: %d\n", resultado);
                    } else {
                        printf("Nao e possivel dividir por zero!\n");
                    }
                    break;
            }

        } else if (opcao == 5) {
            printf("Saindo da calculadora...\n");

        } else {
            printf("Opcao invalida!\n");
        }

    } while (opcao != 5);

    return 0;
}
