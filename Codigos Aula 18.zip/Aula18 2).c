#include <stdio.h>

int maiorPreco(int preco1, int preco2){
    if(preco1 > preco2){
        return preco1;
}
    else{
        return preco2;
    }
}


int main(void){
    
    int preco1, preco2, maior;
    
    printf("Digite o primeiro valor: ");
    scanf("%d", &preco1);
    printf("Digite o segundo valor: ");
    scanf("%d", &preco2);
    
    
    
    printf("Maior preco: %d", maiorPreco(preco1, preco2));
    


    return 0;
}