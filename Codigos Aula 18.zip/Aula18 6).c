
#include <stdio.h>

int calcularFatorial(int n) {
    int resultado = 1;

    for (int i = 1; i <= n; i++) {
        resultado = resultado * i;
    }

    return resultado;
}

int main(void) {
    int numero, resultado;

    printf("Digite um numero entre 0 e 12: ");
    scanf("%d", &numero);

    if (numero >= 0 && numero <= 12) {

        resultado = calcularFatorial(numero);

        printf("Fatorial de %d: %d\n", numero, resultado);

    } else {
        printf("Numero invalido! Digite entre 0 e 12.\n");
    }

    return 0;
}
