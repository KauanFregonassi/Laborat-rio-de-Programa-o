#include <stdio.h>

typedef struct{
    char nome[50];
    int idade;
    float salario;
} Funcionario;

int main(void){
    
    Funcionario funcionario1;
    Funcionario funcionario2;
    float diferenca;
    
    printf("Nome do funcionario 1: ");
    scanf("%49s", funcionario1.nome);
    printf("Idade: ");
    scanf("%d", &funcionario1.idade);
    printf("Salário: ");
    scanf("%f", &funcionario1.salario);
    
    printf("\n");
    
    printf("Nome do funcionario 2: ");
    scanf("%49s", funcionario2.nome);
    printf("Idade: ");
    scanf("%d", &funcionario2.idade);
    printf("Salário: ");
    scanf("%f", &funcionario2.salario);
    
    printf("===================FUNCIONARIOS==================\n");
    
    printf("Funcionário 1\n");
    printf("Nome: %s\n", funcionario1.nome);
    printf("Idade: %d\n", funcionario1.idade);
    printf("Salário: R$%.2f\n", funcionario1.salario);
    
    
    
    printf("\n-----------------------------------------------\n");
    
    printf("Funcionário 2\n");
    printf("Nome: %s\n", funcionario2.nome);
    printf("Idade: %d\n", funcionario2.idade);
    printf("Salário: R$%.2f\n", funcionario2.salario);
    
    
    
    printf("\n==============DIFERENÇA SALARIAL================\n");
    
    if(funcionario1.salario == funcionario2.salario){
        printf("Ambos tem o salário igual.");
    }
    else{
        diferenca = funcionario1.salario - funcionario2.salario;
    
        printf("A diferença do salário de ambos é de R$%.2f\n", diferenca);
    
        if(funcionario1.salario > funcionario2.salario){
            printf("\nSendo %s com o maior salário", funcionario1.nome);
        }
        else{
            printf("\nSendo %s com o maior salário", funcionario2.nome);
        }    
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}