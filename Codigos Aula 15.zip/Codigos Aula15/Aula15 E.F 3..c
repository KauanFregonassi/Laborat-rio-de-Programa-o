
#include <stdio.h>

int main(void)
{
    int numeros[3][3] = {
        {0,0,0},
        {0,0,0},
        {0,0,0}
    };
    
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            printf("Escreva um valor: ");
            scanf("%d", &numeros[i][j]);
        }
    }
    
    int pares = 0;
    
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            if(numeros[i][j] %2 == 0){
                pares++;
            }
            
        }
    }
    printf("Contém %d números pares!", pares);
    return 0;
}