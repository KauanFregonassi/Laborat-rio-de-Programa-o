
#include <stdio.h>

int main()
{
    int numeros[3][3]={
        {0,0,0},
        {0,0,0},
        {0,0,0}
    };
    
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            printf("Digite um número: ");
            scanf("%d", &numeros[i][j]);
            
        }
    }
    
    int maior = numeros[0][0];
    
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            if(numeros[i][j] > maior){
                maior = numeros[i][j];
            }
            
        }
    }

    printf("O maior número é: %d", maior);
    
    
    return 0;
}