
#include <stdio.h>

int main(void)
{
    int numeros[2][3] = {
        {0, 0, 0},
        {0, 0, 0}
    };

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            printf("Digite um numero: ");
            scanf("%d", &numeros[i][j]);
        }
    }

    int soma = 0;

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 3; j++) {
            soma += numeros[i][j];
        }
    }

    printf("%d\n", soma);

    return 0;
}