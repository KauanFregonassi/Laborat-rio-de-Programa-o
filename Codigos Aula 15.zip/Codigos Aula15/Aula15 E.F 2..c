#include <stdio.h>

int main(void)
{
    float numeros[3][2] = {
        {0, 0},
        {0, 0},
        {0, 0}
    };

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 2; j++) {
            printf("Digite a nota da prova do aluno %d: ", i + 1);
            scanf("%f", &numeros[i][j]);
        }
    }

    for (int i = 0; i < 3; i++) {
        float media = 0;

        for (int j = 0; j < 2; j++) {
            media += numeros[i][j];
        }

        media = media / 2.0;

        printf("Media do aluno %d: %.1f\n", i + 1, media);
    }

    return 0;
}