#include <stdio.h>

int main() {

    int numeros[5];
    int *p;

    for(int i = 0; i < 5; i++){
        printf("Digite um número: ");
        scanf("%d", &numeros[i]);
        p = &numeros[i];
    }
    
    p = &numeros[0];
    
    for(int i = 0; i < 5; i++){
        printf("Os números são: %d\n", *p);
        p++;
    }
    
    return 0;
}