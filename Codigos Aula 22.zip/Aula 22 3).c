#include <stdio.h>

int main() {

    int numero = 15;
    int *p = &numero;


    printf("\n=== RESULTADO ===\n");

    printf("Valor: %d\n", numero);
    *p = 50;
    printf("Valor: %d\n", *p);
    
    return 0;
}