
#include <stdio.h>

void dobrar(int *p) {

    *p = *p * 2;

}

int main() {

    int numero;

    printf("Digite um numero: ");
    scanf("%d", &numero);

    dobrar(&numero);

    printf("\n=== RESULTADO ===\n");
    printf("Valor dobrado: %d\n", numero);

    return 0;
}
