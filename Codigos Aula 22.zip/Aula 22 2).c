#include <stdio.h>

int main() {

    int numero = 20;
    int *p;

    p = &numero;

    printf("\n=== RESULTADO ===\n");

    printf("Valor: %d\n", numero);
    printf("Endereco de memoria: %p\n", &numero);
    printf("Valor acessado pelo ponteiro: %d", *p);
    
    return 0;
}